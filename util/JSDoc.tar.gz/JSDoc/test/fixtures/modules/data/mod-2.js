/** @module my/module/name */
define({
    property: "foo",
    method: function() {}
});