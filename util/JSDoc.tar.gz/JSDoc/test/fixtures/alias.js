var myObject = (function() {
    
    /** Give x another name.
        @alias myObject
        @namespace 
     */
    var x = {
        /** document me */
        myProperty: 'foo'
    }
    
    return x;
})();