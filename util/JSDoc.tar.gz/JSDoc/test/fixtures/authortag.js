/** @constructor
    @author Michael Mathews <micmath@gmail.com>
*/
function Thingy() {
    
}