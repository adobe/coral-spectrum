/**
*  @returns { String | Array<String>}  The names of the found item(s).
*/
function find(targetName) {
}

/**
*  @return The binding id.
*/
function bind(callback) {
}
