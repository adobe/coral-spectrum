/**
*  @requires module:foo/helper
*/
function foo() {
}

/**
* @requires foo
* @requires Pez#blat this text is ignored
*/
function bar() {
}
