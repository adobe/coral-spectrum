/** @constructor 
    @memberof mathlib
 */
function Data() {

    /** @member */
    this.point = {};
}

/** @namespace */
mathlib = {Data: Data};