/**
    @module {ConnectServer} blog/server 
*/

module.exports = require('connect').createServer(
  Connect.logger(),
  Connect.conditionalGet(),
  Connect.favicon(),
  Connect.cache(),
  Connect.gzip(),
  require('wheat')(env.dirname)
);

/**
    @member {number} module:blog/server.port
    @default 8080
*/