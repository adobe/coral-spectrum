/**
    An automated documentation generator for JavaScript.
    @project JSDoc
    @version 3.0.0
    @copyright 2011 (c) Michael Mathews <micmath@gmail.com>
    @license Apache Version 2 <http://www.apache.org/licenses/LICENSE-2.0>
 */
function blah(url) {
}