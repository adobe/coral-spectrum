/*global describe: true, it: true */
describe("jsdoc/util/doop", function() {
	// TODO
});