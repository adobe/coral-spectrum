/*global describe: true, env: true, it: true */
describe("jsdoc/augment", function() {
    // TODO
});
