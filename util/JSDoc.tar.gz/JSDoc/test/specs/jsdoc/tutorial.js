/*global describe: true, env: true, it: true */
describe("jsdoc/tutorial", function() {
	//TODO
});